package pricecomparison;

public class ProductData extends Database{
    public String getData() {
        return null;
    }
}
