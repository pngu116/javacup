package pricecomparison;

public class ProductSearch extends Client{
    public void search() {
        
    }
    
    public void viewList() {
        
    }
}
