package pricecomparison;

public class Account extends Client{
    public void signUp() {
        
    }
    
    public void signIn() {
        
    }
    
    public void profile() {
        
    }
}
