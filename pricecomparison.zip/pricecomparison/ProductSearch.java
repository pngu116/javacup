package pricecomparison;

/**
 *
 * @author khoif
 */
public interface ProductSearch extends Client{
    void search();
    
}
