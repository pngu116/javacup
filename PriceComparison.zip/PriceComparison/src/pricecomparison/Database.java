package pricecomparison;

public class Database extends PriceComparison{
    
}
