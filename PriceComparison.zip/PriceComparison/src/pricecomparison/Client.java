package pricecomparison;

public class Client extends PriceComparison{
    
}
