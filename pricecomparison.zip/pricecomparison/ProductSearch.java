package pricecomparison;

/**
 *
 * @author khoif
 */
public interface ProductSearch {
    public void search();
    
    public void viewList();
}
