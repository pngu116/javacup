package pricecomparison;

import java.util.ArrayList;

public class Application extends PriceComparison{
    private class DataFulfillment {
        public String getRequest() {
            
            return null;
        }
        
        public void checkValidity() {
            
        }
        
        public String getProduct() {
            
            return null;
        }
        
        public ArrayList makeList() {
            
            return null;
            
        }
    }
}
