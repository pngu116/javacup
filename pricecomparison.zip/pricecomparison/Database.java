package pricecomparison;

public class Database extends PriceComparison{
    private class ProductData {
        public String getData() {
            
            return null;
        }
    }
    
    private class DataStorage {
        public int getProductPrice() {
            
            return 0;
        }
        
        public String getProductName() {
            
            return null;
        }
    }
}
