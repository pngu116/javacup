package pricecomparison;

import java.util.List;

public class DataFulfillment extends Application{
    public String getRequest() {
        return null;
    }
    
    public void checkValidity() {
        
    }
    
    public String getProduct() {
        return null;
    }
    
    public List<String> makeList() {
        return null;
    }
}
