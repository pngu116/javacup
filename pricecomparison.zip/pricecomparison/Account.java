package pricecomparison;

/**
 *
 * @author khoif
 */
public interface Account {
    public void signUp();
    
    public void signIn();
    
    public void profile();
}
