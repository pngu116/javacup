package pricecomparison;

public class Client {
    private class Account extends PriceComparison{
        public void signUp() {
            
        }
        
        public void signIn() {
            
        }
        
        public void profile() {
            
        }
    }
    
    private class ProductSearch {
        public void search() {
            
        }
        
        public void viewList() {
            
        }
    }
}
