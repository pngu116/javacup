package pricecomparison;

/**
 *
 * @author khoif
 */
public interface DataFulfillment {
    public void getRequest();
    
    public void checkValidity();
    
    public void getProduct();
    
    public void makeList();
}
