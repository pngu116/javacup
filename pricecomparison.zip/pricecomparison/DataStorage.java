package pricecomparison;

/**
 *
 * @author khoif
 */
public interface DataStorage {
    public void getProductPrice();
    
    public void getProductName();
}
