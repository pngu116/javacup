package pricecomparison;

/**
 *
 * @author khoif
 */
public interface Account extends Client{
    public void createLogin();
    
    public void signIn();
    
    public void profile();
}
