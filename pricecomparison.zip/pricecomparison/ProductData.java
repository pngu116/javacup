package pricecomparison;

/**
 *
 * @author khoif
 */
public interface ProductData {
    public void getData();
}
