/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package productsearch;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author tambl
 */
public class ProductSearch {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.print("Enter Product name: ");
        String product  = s.next();
        String line = "";
        
        try{
            FileInputStream f = new FileInputStream("productData.txt");
            Scanner sc = new Scanner(f);
            while(sc.hasNextLine()){
                line = sc.nextLine();
                if(line.startsWith(product)){
                    System.out.println(line);
                }
            }
        }
       catch(IOException ioe){
           ioe.printStackTrace();
       }
    }
    
}
