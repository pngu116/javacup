package pricecomparison;

/**
 *
 * @author khoif
 */
public interface Client extends Account, ProductSearch{
    
}
