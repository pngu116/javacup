package pricecomparison;

/**
 *
 * @author khoif
 */
public interface Client extends Application{
    
}
