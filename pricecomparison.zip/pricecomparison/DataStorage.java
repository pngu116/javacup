package pricecomparison;

/**
 *
 * @author khoif
 */
public interface DataStorage extends Database{
    public void getProductprice();
    
    public void getProductname();
}
