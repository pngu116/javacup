package pricecomparison;

public class Application extends PriceComparison{
    
}
