package pricecomparison;

/**
 *
 * @author khoif
 */
public interface Database extends ProductData {

}
