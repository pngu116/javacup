package pricecomparison;

/**
 *
 * @author khoif
 */
public interface Application extends DataFulfillment {
    
}
