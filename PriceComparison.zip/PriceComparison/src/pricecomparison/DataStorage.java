package pricecomparison;

public class DataStorage extends Database{
    public int getProductPrice() {
        return 0;
    }
    
    public String getProductName() {
        return null;
    }
}
