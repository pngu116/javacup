package pricecomparison;

/**
 *
 * @author khoif
 */
public interface DataFulfillment extends Application{
    void getProduct();
    
    void getRequest();
}
